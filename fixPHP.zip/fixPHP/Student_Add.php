<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
require_once (dirname(__file__) . '/DB_Config.php');
require_once (dirname(__file__) . '/Header.php');
require_once (dirname(__file__) . '/Menu_Bar.php');
require_once (dirname(__file__) . '/Student_Add_C.php');
require_once (dirname(__file__) . '/Footer.php');

?>

<script>$(document).ready(function() {
        "use strict";

        /* Bootstrap switch Init*/
        $('.bs-switch').bootstrapSwitch('state', true);
        $('#check_box_value').text($("#check_box_switch").bootstrapSwitch('state'));

        $('#check_box_switch').on('switchChange.bootstrapSwitch', function () {

            //$("#check_box_value").text($('#check_box_switch').bootstrapSwitch('state'));
            document.getElementById('check_box_value').value = ($('#check_box_switch').bootstrapSwitch('state'));
        });

    });</script>