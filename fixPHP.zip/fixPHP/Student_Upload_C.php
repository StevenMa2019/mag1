<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
if (basename($_SERVER['PHP_SELF']) == basename(__file__))
{
    die('Access Denied, Direct Access Not Premitted!');
}

$dt = new DateTime('now', new DateTimeZone(TMZ));
$CDT = $dt->format('d/m/Y');

function random_password($length = PLength)
{
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
    $password = substr(str_shuffle($chars), 0, $length);
    return $password;
}

function ema($a1,$a2,$a3,$a4)
{
    $message = "Dear " . $a1 . " " . $a2 . ",<br/>";
    $message .= "Your new " . Project_Name . " account has been created.<br/> Welcome to " . Project_Name . "<br/>";
    $message .= "The " . Project_Name . " Id for your account <br/> Email Address is: " . $a3 . "<br/> Password is: " . $a4 . " <br/> Kindly use the above details to access " . Project_Name . " Portal <br/>";
    $message .= "Hope you enjoy using " . Project_Name . ".";
    $message .= "<hr/><br/>";
    $message .= "<br/> Sincerely,<br/>";
    $message .= "<b>" . Project_Name . " Team</b>";
    require_once("PHPMailer/class.PHPMailer.php");
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = SMTP; // specify main and backup server
    $mail->SMTPAuth = true; // turn on SMTP authentication
    $mail->Port = Port;
    $mail->SMTPSecure = Secure;
    $mail->Username = Username; // SMTP username
    $mail->Password = Password; // SMTP password
    $mail->From = From;
    $mail->FromName = From;
    $mail->AddAddress($a3);
    $mail->IsHTML(true);
    $mail->Subject = Subject;
    $mail->Body = $message;
    $mail->AltBody = $message;
    if (!$mail->Send())
    {
//echo '<script>alert("Message could not be sent.")</script>';
        echo "Mailer Error: " . $mail->ErrorInfo;
        exit;
    } else {

       // echo "<script>alert('Email Send')</script>";
    }
}



if (isset($_POST["btn_add"])) {
    $filename = $_FILES["file"]["tmp_name"];
    if ($_FILES["file"]["size"] > 0)
    {
        $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000000, ",")) !== FALSE)
        {
            $pd = random_password(PLength);
            $hash_password = hash('sha512', $pd);
            $h_pass = md5($hash_password . AUTH_KEY);
            $sql = "INSERT into " . PRE . "users(`Username`, `Password`, `Email_Address`, `First_Name`, `Last_Name`, `College_Name`, `Department`, `Profession`, `Student_Id`, `Role_Id`, `Last_Login`, `Created_Date`, `Created_By` ) VALUES ('" . $getData[0] . "','$pd','" . $getData[1] . "','" . $getData[2] . "','" . $getData[3] . "','" . $getData[4] . "','" . $getData[5] . "','" . $getData[6] . "','" . $getData[7] . "','" . $getData[8] . "','0','$CDT','" . $_SESSION["uid"] . "')";
            $result = mysqli_query($AWSCN, $sql);
            $HP_ID = mysqli_insert_id($AWSCN);
            if($result)
            {
                //echo "<script>alert('Result Send')</script>";
                $que = "INSERT INTO " . PRE . "instances(`User_Id`, `Instance_Name`, `Instance_No`, `Instance_Status`, `IP_Address`, `Public_Url`, `Instance_Date`, `Vol_ID`) VALUES ('$HP_ID',' ',' ',' ',' ',' ',' ',' ')";
                $re = mysqli_query($AWSCN, $que);
                $HP_IDS = mysqli_insert_id($AWSCN);
                $sql = "Insert into " . PRE . "records values('$HP_ID','$HP_IDS','$CDT','5')";
                $reult = mysqli_query($AWSCN, $sql);
				echo "<script type=\"text/javascript\">
					alert(\"CSV File has been successfully Imported Sucessfully.\");
						window.location = \"Admin_Home.php\"
					</script>";
            //    print_r($re);
    /*            if ($re)
                {

                    ema($getData[2],$getData[3],$getData[1],$pd);
                   echo "<script>alert('Instance Send')</script>";
                   echo "<script type=\"text/javascript\">
					alert(\"CSV File has been successfully Imported Sucessfully.\");
						window.location = \"Admin_Home.php\"
					</script>";
                } else
                    {
                    echo "<script>alert('Instance Not Send')</script>";
                    echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							window.location = \"Admin_Home.php\"
						  </script>";
                }
      */      }
        }
        fclose($file);
    }
}

?>
<div class="page-wrapper" style="min-height: 301px;">
    <div class="container-fluid">


        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default card-view">
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h6 class="panel-title txt-dark">Student Csv Insertion</h6>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="form-wrap">
                                        <form id="basicform" name="basicform" method="post"
                                              enctype="multipart/form-data">
                                            <div class="form-body">
                                                <div class="pb-10">
                                                    <h6 class="txt-dark capitalize-font"><i
                                                                class="zmdi zmdi-account mr-10"></i>File Info</h6>
                                                </div>
                                                <hr class="light-grey-hr">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group mb-30">
                                                            <label class="control-label mb-10 text-left">File
                                                                upload</label>
                                                            <div class="fileinput fileinput-new input-group"
                                                                 data-provides="fileinput">
                                                                <div class="form-control" data-trigger="fileinput"><i
                                                                            class="glyphicon glyphicon-file fileinput-exists"></i>
                                                                    <span class="fileinput-filename"></span></div>
                                                                <span class="input-group-addon fileupload btn btn-info btn-anim btn-file"><i
                                                                            class="fa fa-upload"></i> <span
                                                                            class="fileinput-new btn-text">Select file</span> <span
                                                                            class="fileinput-exists btn-text">Change</span>
														<input type="file" name="file" id="file">
														</span> <a href="#"
                                                                   class="input-group-addon btn btn-danger btn-anim fileinput-exists"
                                                                   data-dismiss="fileinput"><i
                                                                            class="fa fa-trash"></i><span
                                                                            class="btn-text"> Remove</span></a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <hr class="light-grey-hr">

                                                <div class="form-actions mt-10">
                                                    <input type="submit" class="btn btn-success  mr-10" name="btn_add"
                                                           id="btn_add" value="Upload File"/>
                                                </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>