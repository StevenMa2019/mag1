<?php
session_start();
require_once(dirname(__file__) . '/DB_Config.php');
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
//Start
$RID = $_GET["RID"];
$sql1 = mysqli_query($AWSCN, "Select User_Id from " . PRE . "instances where Instance_Id='$RID'");
if ($row = mysqli_fetch_array($sql1)) {
    if($row["User_Id"]==$_SESSION['uid'])
    {
    $sql = "Delete from " . PRE . "records where Instance_Id='$RID' and User_Id=" . $_SESSION['uid'];
    $reult = mysqli_query($AWSCN, $sql);
    if ($reult) {
        echo "<script>
alert('Record Deleted Sucessfully!');
window.location.href='Student_Home.php';  
</script>";

    } else {
        echo "<script>
alert('Issue in Deleting Record, Try Again!');
window.location.href='Student_Home.php';  
</script>";
    }
} else {
    echo "<script>
alert('Manipulation With The Query String! Opps, Sorry!');
window.location.href='Student_Home.php';  
</script>";
}}


?>
