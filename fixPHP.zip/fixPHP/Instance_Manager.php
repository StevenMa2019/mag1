<?php
if(!isset($_SESSION))
{
    session_start();
}
if(empty($_SESSION["uid"]))
{
    header("Location: Login.php");
    die(-1);
}
require_once(dirname(__file__) . '/DB_Config.php');
require 'aws-autoloader.php';

use Aws\Ec2\Ec2Client;

/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
//Start

$ac = $_GET["AC"];
$sql1 = mysqli_query($AWSCN, "Select * from " . PRE . "instances where User_Id=" . $_SESSION['uid']);
if ($row = mysqli_fetch_array($sql1)) {

    $ec2Client = new Ec2Client([
       'region' => 'us-east-2',
    'version' => 'latest',
    'credentials' => [
          'key'    => 'AKIAJYM4ZRLPTXYLE5AA',
          'secret' => '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',
        ],
    ]);

    $action = $ac;

    $instanceIds = array($row["Instance_No"]);

    if ($action == '0')
    {
        $result = $ec2Client->stopInstances(array(
            'InstanceIds' => $instanceIds,

        ));
    } else if ($action == '1') {
        $result = $ec2Client->startInstances(array(
            'InstanceIds' => $instanceIds,
        ));
    } else if($action=='2') {
        $result = $ec2Client->rebootInstances(array(
            'InstanceIds' => $instanceIds,
        ));
    }
    else {
        echo "<script>
    alert('Invalid Argument Passed!');
window.location.href = 'Student_Home.php';
</script> ";
        die(-1);
    }
	sleep(20);
    $sql = "Insert into " . PRE . "records values('" . $_SESSION['uid'] . "','" . $row["Instance_Id"] . "','$CDT','$ac')";
    $reult = mysqli_query($AWSCN, $sql);
    $result23 = $ec2Client->describeInstances();
    $reservations = $result23['Reservations'];

    foreach ($reservations as $reservation) {
        $instances = $reservation['Instances'];

        foreach ($instances as $instance)
        {
            $instanceName = ' ';

            foreach ($instance['Tags'] as $tag)
			{
                if ($tag['Key'] == 'Name')
				{
                    $instanceName = $tag['Value'];
					if($instanceName == $row['Instance_Name'] && $instance['InstanceId'] == $row['Instance_No'])
					{
						 $query = "UPDATE " . PRE . "instances SET Instance_Status='" . $instance['State']['Name'] . "',IP_Address='" . $instance['PublicIpAddress'] . "', Public_Url='" . $instance['PublicDnsName'] . "',Instance_Date='$CDT'  WHERE User_Id=".$_SESSION['uid'];
						$resx = mysqli_query($AWSCN, $query);
					}
                }
            }
            
            if ($resx) {
                echo "<script>
alert('Request Executed Sucessfully!');
window.location.href = 'Student_Home.php';
</script>";
            } else {
                echo "<script>
    alert('Issue With The Instance!');
window.location.href = 'Student_Home.php';
</script> ";
            }


        }
    }
}//var_dump($result);
?>