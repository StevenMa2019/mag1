
<?php
if(!isset($_SESSION))
{
    session_start();
}
if(empty($_SESSION["uid"]))
{
    header("Location: Login.php");
    die(-1);
}
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
$sql1 = mysqli_query($AWSCN, "Select Count(Record_Id) as re, User_Id from " . PRE . "records where User_Id=".$_SESSION['uid']);
if ($row = mysqli_fetch_array($sql1)) {
if($row["User_Id"]==$_SESSION['uid'] && $row["re"]>30) {
    $sql = "Delete from " . PRE . "records where User_Id=" . $_SESSION['uid'] . " order by Record_Id ASC limit 30";
    $result = mysqli_query($AWSCN, $sql);

}}
?>
