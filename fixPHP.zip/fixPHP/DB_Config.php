<?php

/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */

if (basename($_SERVER['PHP_SELF']) == basename(__file__))
{
    die('Access Denied, Direct Access Not Premitted!');
}

define('Title', '');
define('Footer_Text','Developed By Sachi Patel');
define('Project_Name','AWS');
define('Author','AWS');

//-------------------------------
//Define AWS Credentials
//-------------------------------

define('AWSKEY','AKIAJYM4ZRLPTXYLE5AA');
define('AWSSECRET','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');
define('AWSREGION','us-east-2');
define('AWSVERSION','latest');
define('INSTANCETYPE','t2.micro');
define('SECURITYGROUP','launch-wizard-2');
define('KEYPAIR','metron-cluster');

//-------------------------------
//Define User Password Length
//-------------------------------

define('PLength','10');

//-------------------------------
//Define sending email notification to webmaster & User
//-------------------------------

define('Email_Address','bolexapp@gmail.com');
define('Subject', 'New User Registration Notification');
define('From','bolexapp@gmail.com');
define('Username','bolexapp@gmail.com');
define('Password','bolexapp1234');
define('SMTP','smtp.gmail.com'); //smtp.gmail.com
define('Port','465'); // 465 or 567
define('Secure','ssl'); // ssl or tls

//-------------------------------
//Define TimeZone
//-------------------------------
define('TMZ','Asia/Kolkata');

//-------------------------------
// Authentication Salts
//-------------------------------

define('AUTH_KEY', 'sSrd88vI5l73.9FeV&m?^ghvp{bl6$(?a`)RvsvK|MTbeu-yxnAAOTIE1*!vZz(~');
define('SECOND_AUTH_KEY', 'OeD}|n/A`IiVZB;5|N36mHQ2BU8prJ4aXRO?+*FewLYmSBG6Ea-+OPZ]UOtt/Fri');
define('SESSION_KEY', 'Nk^+.s<(`pI4^V9}z4B-LUm;krBK+3+$8}q,07 SaBNI)4.xBKuIBAwM2Q._B7h{');

//-------------------------------
//Error Reporting (0 off|1 On)
//-------------------------------

error_reporting(E_ALL);
@ini_set("display_errors", 1);

//-------------------------------
//Mode of Project Operation (Development 0 | Production 1)
//-------------------------------

define('MOP', '0');

//-------------------------------
//Database Connection Details
//-------------------------------

//-------------------------------
//Database Prefix
//-------------------------------
define('PRE','aws_');

//-------------------------------
//----- Official Credentials (Production Mode)
//-------------------------------
if (MOP == 1)
{
    /** The Name of the database for AWS Project */
    define('DB_NAME', 'AWS');
    /** MySQL Database Username */
    define('DB_USER', 'root');
    /** MySQL Database Password */
    define('DB_PASSWORD', '1234');
    /** MySQL HostName */
    define('DB_HOST', 'localhost');
}
//-------------------------------
//----- Localhost Credentials (Development Mode)
//-------------------------------
else
{
    /** The Name of the database for AWS Project */
    define('DB_NAME', 'AWS');
    /** MySQL Database Username */
    define('DB_USER', 'root');
    /** MySQL Database Password */
    define('DB_PASSWORD', '1234');
    /** MySQL HostName */
    define('DB_HOST', 'localhost');
}

//-------------------------------
//Server Connection String
//-------------------------------

$AWSCN = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$AWSCN)
{
    echo "<b>Error:</b> Unable to connect to MySQL. <br/>" . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL . "<br/>";
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

/* That's all, stop editing! Happy Testing. */
if (!defined('ABSPATH'))
    define('ABSPATH', dirname(__file__) . '/');