<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
session_start();
echo $_SESSION['uid'];
?>