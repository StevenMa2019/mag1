<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
?>
<?php
require_once (dirname(__file__) . '/DB_Config.php');
require_once (dirname(__file__) . '/Header.php');
require_once (dirname(__file__) . '/Menu_Bar.php');
require_once (dirname(__file__) . '/Admin_Home_C.php');
require_once (dirname(__file__) . '/Footer.php');
?>
