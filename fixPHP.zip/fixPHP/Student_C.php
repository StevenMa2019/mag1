<?php
if(!isset($_SESSION))
{
    session_start();
}


/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
if (basename($_SERVER['PHP_SELF']) == basename(__file__))
{
    die('Access Denied, Direct Access Not Premitted!');
}
?>
<!-- Main Content-->
<div class="page-wrapper">
    <div class="container-fluid pt-25">
        <!-- Buttons Row -->
        <div class="row">
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-default card-view panel-refresh">
                    <div class="refresh-container">
                        <div class="la-anim-1"></div>
                    </div>
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h6 class="panel-title txt-dark">Start Instance</h6>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <div class="text-center">
                                <a href="Instance_Manager.php?AC=1" class="btn btn-success btn-anim"><i class="icon-login"></i><span class="btn-text">Start</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="panel panel-default card-view panel-refresh">
                    <div class="refresh-container">
                        <div class="la-anim-1"></div>
                    </div>
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h6 class="panel-title txt-dark">Stop Instance</h6>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <div class="text-center">
                                <a href="Instance_Manager.php?AC=0" class="btn btn-danger btn-anim"><i class="icon-logout"></i><span class="btn-text">Stop</span></a></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="panel panel-default card-view panel-refresh">
                    <div class="refresh-container">
                        <div class="la-anim-1"></div>
                    </div>
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h6 class="panel-title txt-dark">Reboot Instance</h6>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body">
                            <div class="text-center">
                            <a href="Instance_Manager.php?AC=2" class="btn btn-warning btn-anim"><i class="icon-refresh"></i><span class="btn-text">Reboot</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Row -->
        <!-- Table Row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default card-view">
                    <div class="panel-heading">
                        <div class="pull-left">
                            <h6 class="panel-title txt-dark">Past Instances Records</h6>
                        </div>
                        <div class="pull-right">
                            <a href="#" class="pull-left inline-block full-screen">
                                <i class="zmdi zmdi-fullscreen"></i>
                            </a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-wrapper collapse in">
                        <div class="panel-body row ">
                            <div class="table-wrap">
                                <div class="table-responsive">
                                    <table id="datable_1" class="table table-hover display  pb-30" >
                                        <thead>
                                        <tr>
                                            <th>Record Id</th>
                                            <th>Instance Id</th>
                                            <th>Ip Address</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                                        $querys = mysqli_query($AWSCN, "select Record_Id,ar.User_Id as UID, ar.Instance_Id as RID,ar.Status,ar.IDate,ai.IP_Address FROM ".PRE."records ar, ".PRE."instances ai where ar.User_Id=ai.User_Id and ar.Instance_Id=ai.Instance_Id and ai.User_Id=".$_SESSION['uid']);
                                        if($querys)
										{
										while ($row = mysqli_fetch_array($querys))
                                        {
                                            ?>

                                            <tr>
                                                <td><?php echo $row["Record_Id"] ?></td>
                                                <td><?php echo $row["RID"] ?></td>

                                                <td><?php echo $row["IP_Address"] ?></td>
                                                <td><?php echo $row["IDate"] ?></td>
                                                <td><?php $ed=$row["Status"];
                                                    if($ed=='0')
                                                    { ?>
                                                        <span class="label label-danger text-uppercase">Stop</span>
                                                        <?php
                                                    }
                                                    else if($ed=='1')
                                                    {
                                                        ?>
                                                        <span class="label label-success text-uppercase">Running</span>
                                                    <?php }
                                                    else
                                                        {
                                                    ?>
                                                    <span class="label label-warning text-uppercase">Restart</span>
                                                    <?php }?>

                                                </td>
                                                <td><a href="Student_Delete.php?RID=<?php echo $row["RID"] ?>" class="text-inverse" title="" data-toggle="tooltip" data-original-title="Delete this Record"><i class="zmdi zmdi-delete"></i></a></td>


                                            </tr>
                                        <?php } }?>
                                        </tbody>

                                        <tfoot>
                                        <tr>
                                            <th>Instance Id</th>
                                            <th>Instance Name</th>
                                            <th>Ip Address</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Action</th>

                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
