<?php
if(!isset($_SESSION))
{
    session_start();
}
if(empty($_SESSION["uid"]))
{
    header("Location: Login.php");
    die(-1);
}
require_once(dirname(__file__) . '/DB_Config.php');
require 'aws-autoloader.php';

use Aws\Ec2\Ec2Client;

/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
//Start

$ac = $_GET["RID"];
$sql1 = mysqli_query($AWSCN, "Select * from " . PRE . "instances where User_Id=$ac");
if ($row = mysqli_fetch_array($sql1)) 
{

    $ec2Client = new Ec2Client([
       'region' => 'us-east-2',
    'version' => 'latest',
    'credentials' => [
          'key'    => 'AKIAJYM4ZRLPTXYLE5AA',
          'secret' => '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',
        ],
    ]);

    $action = 0;

    $instanceIds = array($row["Instance_No"]);
	$vol = array($row["Vol_ID"]);
}
    if ($action == '0')
    {
        $result = $ec2Client->terminateInstances(array(
            'InstanceIds' => $instanceIds,

        ));
		
		sleep(50);
    $result = $ec2Client->deleteVolume(array(
		'VolumeId' => $vol[0],
));

	//	$sql = "Delete from " . PRE . "users where User_Id=$ac";
	
	$sql = "UPDATE " . PRE . "instances SET Instance_Name=' ', Instance_No=' ', Instance_Status=' ',IP_Address=' ', Public_Url=' ',Instance_Date=' ', Vol_ID=' '  WHERE User_Id=$ac";
                   
    $result = mysqli_query($AWSCN, $sql);
            if ($result) {
                echo "<script>
alert('Request Executed Sucessfully!');
window.location.href = 'Admin_Home.php';
</script>";
            } else {
                echo "<script>
    alert('Issue With The Instance Termination!');
window.location.href = 'Admin_Home.php';
</script> ";
            }


        }

else
{
	   echo "<script>
    alert('Error With The Instance Termination!');
window.location.href = 'Admin_Home.php';
</script> ";
}
   
?>
