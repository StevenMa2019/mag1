<?php
if(!isset($_SESSION))
{
    session_start();
}
if(empty($_SESSION["uid"]))
{
    header("Location: Login.php");
    die(-1);
}
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
require_once (dirname(__file__) . '/DB_Config.php');
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
$dt = new DateTime('now', new DateTimeZone(TMZ));
$CDT = $dt->format('d/m/Y');

$EID=$_GET["em"];
$UID="";

require 'aws-autoloader.php' ;

use Aws\Ec2\Ec2Client ;

$ec2Client = new Ec2Client([
    'region' => 'us-east-2',
    'version' => 'latest',
    'credentials' => [
          'key'    => 'AKIAJYM4ZRLPTXYLE5AA',
          'secret' => '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',
    ],
]);

// describe the key pair
$keyPairName = 'metron-cluster';//KEYPAIR;
$result = $ec2Client->describeKeyPairs(array(
    'KeyName' => $keyPairName
));

// Save the private key
$saveKeyLocation = getenv('HOME') . ".ssh/{$keyPairName}.pem";
file_put_contents($saveKeyLocation, $result['keyMaterial']);

// Update the key's permissions so it can be used with SSH
chmod($saveKeyLocation, 0600);

// describe the security group
$securityGroupName = 'launch-wizard-2';//SECURITYGROUP;
$result = $ec2Client->describeSecurityGroups(array(
    'GroupName'   => $securityGroupName,
    'Description' => 'AWS SERVER'
));

// Get the security group ID (optional)
$securityGroupId = $result->get('GroupId');

$n = array();
$n1 = array();
$userdata2 = fopen("encoded.txt", "r") or die("Unable to open file!");

foreach($EID as $name)
{

// Launch an instance with the key pair and security group
    $result = $ec2Client->runInstances(array(

    'BlockDeviceMappings' => array(
                'Ebs' => array(
					'DeleteOnTermination' => true,
            ),
        ),
		'ImageId' => 'ami-20271545',
        'MinCount' => 1,
        'MaxCount' => 1,
        'InstanceType' => 't2.micro',//INSTANCETYPE,
        'KeyName' => $keyPairName,
        'SecurityGroups' => array($securityGroupName),
	//	'UserData' => fread($userdata2,filesize("encoded.txt")),//$userdata2,
	    'Tags' => array(
            'Tag' => array(
                'Key' => 'Name',
                'Value' => $name,
            ))
    ));

    $sql1 = mysqli_query($AWSCN,"SELECT * FROM " . PRE . "users where Email_Address = '" . $name . "'");
	$row = mysqli_fetch_array($sql1);
 //   $result = mysqli_query($AWSCN, $sql1);
 //   $row = mysqli_num_rows($result);
    if ($row > 0)
    {
        $UID = $row["User_Id"];
    }
	array_push($n1,$row["User_Id"]);
    array_push($n,$name);
}
//$instanceIds = $result->getPath('Instances/*/InstanceId');

sleep(40);

$i=0;
$iis="";
$result23 = $ec2Client->DescribeInstances();

$vol = " ";
//echo $result23;

//sleep(5);

$reservations = $result23['Reservations'];

foreach ($reservations as $reservation)
{
    $instances = $reservation['Instances'];

    foreach ($instances as $instance)
    {
		$BlockDeviceMappings = $instance['BlockDeviceMappings'];		
				
		$instanceName = ' ';
        if($instance['State']['Name']=='running')
        {
			foreach ($BlockDeviceMappings as $BDM)
			{
				$vol = $BDM['Ebs']['VolumeId'];
			}
			foreach($instance['Tags'] as $tag)
            {
                if($tag['Key'] == 'Name')
                {
                    $instanceName = $tag['Value'];
                }
            }
			
            if(!empty($instanceName))
            {
              //  echo 'Instance Name: ' . $instanceName . PHP_EOL;
              //  echo '<br>';
            }

            if(!empty($instance['PublicIpAddress']))
            {
               // echo '---> IPV4: ' . $instance['PublicIpAddress'] . PHP_EOL;
               // echo '<br>';
            }

            if(!empty($instance['State']['Name']))
            {
               // echo '---> State: ' . $instance['State']['Name'] . PHP_EOL;
               // echo '<br>';
            }

            if(!empty($instance['InstanceId']))
            {
              //  echo '---> Instance ID: ' . $instance['InstanceId'] . PHP_EOL;
                $iis=$instance['InstanceId'];
               // echo '<br>';
            }

            if(!empty($instance['PublicDnsName']))
            {
              //  echo '---> Public Dns Name: ' . $instance['PublicDnsName'] . PHP_EOL;
              //  echo '<br>';
            }
			
			if(!empty($instance['BlockDeviceMappings']['Ebs']['VolumeId']))
            {               
				//echo '---> volume id   : ' . $instance['BlockDeviceMappings']['Ebs']['VolumeId'] . PHP_EOL;
              //  echo '<br>';				
			}

            if(!empty($instance['StateTransitionReason']))
            {
                $ys=$instance['StateTransitionReason'];
               // echo '---> State Transition Reason: ' . $instance['StateTransitionReason'] . PHP_EOL;
               // echo '<br>';
            }
            else
            {

					//$query123="UPDATE".PRE." users SET IP_ADDRESS ='".$instance['PublicIpAddress']."', Instance_ID='".$instance['InstanceId']."' WHERE EMAIL ='".$n[$i]."'";
                    //mysqli_query($AWSCN,$query123);

                   $query = "UPDATE " . PRE . "instances SET Instance_Name='" . $n[$i] . "', Instance_No='" . $instance['InstanceId'] . "', Instance_Status='" . $instance['State']['Name'] . "',IP_Address='" . $instance['PublicIpAddress'] . "', Public_Url='" . $instance['PublicDnsName'] . "',Instance_Date='".$CDT."', Vol_ID='".$vol."'  WHERE User_Id='".$n1[$i]."'";
                   $resx= mysqli_query($AWSCN, $query);
                    $result1 = $ec2Client->createTags(array(
                        'Resources' => array($iis),
                        'Tags' => array(
                            'Tag' => array(
                                'Key' => 'Name',
                                'Value' => $n[$i],//$EID,
                            )
                        )
                    ));
                    $i++;
                    if($resx)
                    {
                        echo "<script>
alert('Fetched IDS -> Redirecting to Main Page!');
window.location.href='Admin_Home.php?Flag=1';  
</script>";
                    }
                    else
                    {
                        echo "<script>
alert('Fetched IDS -> Redirecting to Main Page!');
window.location.href='Admin_Home.php?Flag=0';  
</script>";
                    }

            }
         //   echo '-----------------------------------------------------------------------------------------------------';
          //  echo '<br>';
          //  echo '<br>';
        }
    }
}
?>
