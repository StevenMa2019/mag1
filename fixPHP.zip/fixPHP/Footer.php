<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
?>
<!-- Footer -->
<footer class="footer container-fluid pl-30 pr-30">
    <div class="row">
        <div class="col-sm-12">
            <p><?php echo Footer_Text ?></p>
        </div>
    </div>
</footer>
<!-- /Footer -->

</div>
<!-- /Main Content -->

</div>
<!-- /#wrapper -->

<!-- JavaScript -->

<!-- jQuery -->
<script src="../vendors/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Moment JavaScript -->
<script type="text/javascript" src="../vendors/bower_components/moment/min/moment-with-locales.min.js"></script>

<!-- Counter Animation JavaScript -->
<script src="../vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="../vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>

<!-- Data table JavaScript -->
<script src="../vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="dist/js/productorders-data.js"></script>
<script src="dist/js/dataTables-data.js"></script>
<!-- Bootstrap Switch JavaScript -->
<script src="../vendors/bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js"></script>
<!-- Select2 JavaScript -->
<script src="../vendors/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- Owl JavaScript -->
<script src="../vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

<!-- Switchery JavaScript -->
<script src="../vendors/bower_components/switchery/dist/switchery.min.js"></script>

<!-- Slimscroll JavaScript -->
<script src="dist/js/jquery.slimscroll.js"></script>

<!-- Bootstrap Switch JavaScript -->
<script src="../vendors/bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js"></script>

<!-- Fancy Dropdown JS -->
<script src="dist/js/dropdown-bootstrap-extended.js"></script>
<script src="../vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>
<!-- Sparkline JavaScript -->
<script src="../vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>

<!-- EChartJS JavaScript -->
<script src="../vendors/bower_components/echarts/dist/echarts-en.min.js"></script>
<script src="../vendors/echarts-liquidfill.min.js"></script>

<!-- Toast JavaScript -->
<script src="../vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js"></script>

<!-- Init JavaScript -->
<script src="dist/js/init.js"></script>




</body>
</html>
