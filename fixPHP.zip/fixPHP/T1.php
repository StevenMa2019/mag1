<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
error_reporting(1);
function execInBackground($cmd){
    if (substr(php_uname(), 0, 7) == "Windows"){
        pclose(popen("start /B ". $cmd, "r"));
        echo "\nSexy World";
    }else{
        exec($cmd . " > /dev/null &");
    }
}
execInBackground('D:\JES\bin\php\php7.1.5\php.exe Tests.php');
echo "\n Hello World";
?>