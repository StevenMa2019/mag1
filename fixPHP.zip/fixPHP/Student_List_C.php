<?php
/**
 * Developed By: Sachi Patel
 * Code Version: 1.0
 */
 if (basename($_SERVER['PHP_SELF']) == basename(__file__)) {
    die('Access Denied, Direct Access Not Premitted!');
}
if (isset($_POST["btn_add"]))
{
	//Start
	//Putting Resources of Contribution In Array
    if (isset($_POST['chk']))
    {
        $Resource_list = array();
        foreach ($_POST['chk'] as $val)
        {
            $Resource_list[] = (string )$val;
        }
        $Resource_list = implode(',', $Resource_list);
    }
    echo "<script>
alert('Fetched IDS -> Redirecting to Create Instance!');
window.location.href='Multiple_Instance.php?Email=$Resource_list';  
</script>";
  }
?>
<script>
    function checkAll() {
        var checkboxes = document.getElementsByTagName('input');
        var val = null;
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type == 'checkbox') {
                if (val === null) val = checkboxes[i].checked;
                checkboxes[i].checked = val;
            }
        }
    }

</script>
<div class="page-wrapper">
    <div class="container-fluid pt-25">

<!-- Table Row -->
<div class="row">
    <div class="col-sm-12">
        <form id="bes" name="bes" method="post">
        <div class="panel panel-default card-view">
            <div class="panel-heading">
                <div class="pull-left">
                    <h6 class="panel-title txt-dark">Student Details</h6>
                </div>
                <div class="pull-right">
                    <a href="#" class="pull-left inline-block full-screen">
                        <i class="zmdi zmdi-fullscreen"></i>
                    </a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="panel-wrapper collapse in">
                <div class="panel-body row ">
                    <div class="table-wrap">
                        <div class="table-responsive">
                            <table id="datable_1" class="table table-hover display  pb-30" >
                                <thead>
                                <tr>
                                    <th data-orderable="false"><INPUT type="checkbox" onchange="checkAll()" name="chk1[]" />
                                    </th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email Address</th>
                                    <th>Date Added</th>
                                    <th>Status</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php
    $querys = mysqli_query($AWSCN, "SELECT * FROM " . PRE . "users where Role_Id>'1'");
    while ($row = mysqli_fetch_array($querys))
    {
                                ?>

                                <tr>
                                    <td><INPUT type="checkbox" name="chk[]" value="<?php echo $row["Email_Address"] ?>" /></td>
                                    <td><?php echo $row["First_Name"] ?></td>
                                    <td><?php echo $row["Last_Name"] ?></td>
                                    <td><?php echo $row["Email_Address"] ?></td>
                                    <td><?php echo $row["Created_Date"] ?></td>
                                    <td><?php $ed=$row["Status"];
                                        if($ed=='0')
                                        { ?>
                                            <span class="label label-danger text-uppercase">Deactive</span>
                                      <?php
                                        }
                                      else
                                      {
                                        ?>
                                    <span class="label label-success text-uppercase">Active</span>
                                    <?php }?>

                                    </td>

                                </tr>
<?php } ?>
                                </tbody>


                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <hr class="light-grey-hr">
        <div class="form-actions">
            <input type="submit" class="btn btn-success mr-10 mb-20" name="btn_add"
                   id="btn_add"  value="Create Instance"/>
        </div>
        </form>
        </div>
    </div>
</div>
    </div>
